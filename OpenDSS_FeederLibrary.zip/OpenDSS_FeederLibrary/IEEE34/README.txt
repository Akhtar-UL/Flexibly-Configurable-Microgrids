Linecodes renamed to LC300.. etc to avoid numeric-name crash in some OpenDSS builds.
