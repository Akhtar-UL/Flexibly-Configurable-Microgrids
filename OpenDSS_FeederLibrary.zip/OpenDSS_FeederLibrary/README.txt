OpenDSS feeder library
======================

How to use:
- Put each feeder in its own subfolder under this directory.
- Each feeder folder should contain a 'Master.dss' file (recommended) or a file
  whose name contains 'master' or 'ckt' (e.g., 'IEEE13Nodeckt.dss').

Suggested structure:
  OpenDSS_FeederLibrary/
    IEEE13/
      Master.dss   (or copy/rename the IEEE13 master here)
    IEEE34/
      Master.dss
    IEEE37/
      Master.dss
    IEEE123/
      Master.dss

Where to get IEEE test feeders:
- If you installed OpenDSS on Windows, they are usually under:
  C:\Program Files\OpenDSS\Examples\
  (or C:\Program Files (x86)\OpenDSS\Examples\)

Tip:
- You can copy an entire IEEE feeder folder from OpenDSS Examples into here.
- If the feeder's entry file is not named Master.dss, either:
    (1) keep the original name (it will still be detected), or
    (2) create a small Master.dss that Redirects the original file.
